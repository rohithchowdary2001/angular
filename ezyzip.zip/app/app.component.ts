import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { UserApi } from './helpers/user-api.service';
import { FormGroup, FormControl, Validators, AbstractControl, ValidatorFn ,FormBuilder} from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import Swal from 'sweetalert2';
import { Action } from './helpers/action.enum';
import { User } from './helpers/user.interface';

import { HttpClient } from '@angular/common/http';
import { startWith } from 'rxjs/operators';

 function emailValidator(control: AbstractControl) {
  const email = control.value;
  const lowercaseEmail = email.toLowerCase();
  const pattern = /^[a-z0-9]+@[a-z0-9]+(\.[a-z0-9]+)+$/;

  if (!email) {
    return { required: true }; // Add the required error if email is empty
  }

  if (email !== lowercaseEmail || /[A-Z]/.test(email)) {
    return { invalidEmail: true };
  }

  if (!pattern.test(email)) {
    return { invalidEmail: true };
  }

  return null;
}
function dateOfBirthValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const currentDate = new Date();
    const enteredDate = new Date(control.value);

    if (!control.value || isNaN(enteredDate.getTime())) {
      return { invalidDate: true };
    }

    if (enteredDate > currentDate) {
      return { futureDate: true };
    }

    const ageDiff = currentDate.getFullYear() - enteredDate.getFullYear();
    const monthDiff = currentDate.getMonth() - enteredDate.getMonth();
    const dayDiff = currentDate.getDate() - enteredDate.getDate();

    if (ageDiff < 18 || (ageDiff === 18 && (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)))) {
      return { underAge: true };
    }

    if (enteredDate.getFullYear() < 1908) {
      return { invalidYear: true };
    }

    return null;
  };
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  users: User[] = [];
  employees: any[] = [];
  title = 'userregistartion';
  addForm: FormGroup;
  submitted: boolean = false;
  buttontext: string = "";
  dbops: Action;
  formTitle: string = "";
  serialNo: number = 1;
  
  columnName: string = '';
  sortAsc: boolean = true;
  searchQuery: string = '';
  serialNoFilter: string = '';
  nameFilter: string = '';
  emailFilter: string = '';
  mobileNoFilter: string = '';
  dobFilter: string = '';

  validateName(control: AbstractControl) {
    const value = control.value;
    const invalidCharacters = /[!@#$%^&*(),.?":{}|<>]/;
    const consecutiveSpaces = /\s{2,}/;
    if (value === null || value === undefined) {
      return null; 
    }
    if (invalidCharacters.test(value)) {
      return { invalidCharacters: true };
    }
  
    if (consecutiveSpaces.test(value)) {
      return { invalidSpaces: true };
    }
  
    const countApostrophes = (value.match(/'/g) || []).length;
    if (countApostrophes > 1) {
      return { invalidApostrophe: true };
    }
  
    return null;
  }
  
  limitNameLength(event: any) {
    const input = event.target;
    const maxLength = 20;
  
    
    const value = (input.value ?? '').replace(/\s{2,}/g, ' ');
  
    
    if (value.length > maxLength) {
      input.value = value.slice(0, maxLength);
    } else {
      input.value = value;
    }
  
    this.addForm.patchValue({ Name: input.value });
  }
  
  
  
  
 



  @ViewChild("content") elContent: any;
  modalRef: any;



  userData: User[] = [];

  constructor(private _toastr: ToastrService, private modalService: NgbModal, private _userApi: UserApi, private _httpService: HttpClient,private fb: FormBuilder) {
}

  ngOnInit() {
    this.setFormState();
    this.getAllUsers();
    console.log('userData:', this.userData);

    this.addForm.statusChanges
    .pipe(startWith(this.addForm.status))
    .subscribe(status => {
      if (status === 'VALID') {
        this.submitted = true;
      }
    });
  }

  resetForm() {
    const maxSerialNo = this.userData.reduce((max, user) => Math.max(max, user.serialno), 0);
    const nextSerialNo = maxSerialNo + 1;
    this.addForm.reset({
      serialno: { value: nextSerialNo, disabled: true }, 
    Name: '', 
    
    Email: '', 
    Mobileno: '', 
    DOB: '', 
    });
    this.addForm.get("DOB")?.setValue(null);
    this.addForm.get("Mobileno")?.setValue(null);
// Clear all validation errors for the form controls
Object.keys(this.addForm.controls).forEach((key) => {
  this.addForm.get(key)?.setErrors(null);
});

// Mark the form as pristine and untouched
this.addForm.markAsPristine();
this.addForm.markAsUntouched();

    this.submitted = false;
    this.buttontext = "submit";
    this.formTitle = "Add Employee";
    this.dbops = Action.create;
  }

  setFormState() {
    this.buttontext = "submit";
    this.formTitle = "Add Employee";
    this.dbops = Action.create;

    if (this.modalRef) {
      this.modalRef.close();
    }

    this.addForm = this.fb.group({
      id: [0],
      serialno: ['', Validators.required],
      Name: ['', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(20),
        Validators.pattern('^[a-zA-Z ]+$'),
        this.validateName
      ]],
     
      Email: ['', [
        Validators.required,
        emailValidator
      ]],
      Mobileno: ['', [
        Validators.required,
        Validators.pattern('^(0|91)?[6-9][0-9]{9}$')
      ]],
      DOB: ['', [
        Validators.required,
        dateOfBirthValidator()]]
    

    });
  }
  




  get control() {
    return this.addForm.controls;
  }
  isFormValid(): boolean {
    return this.addForm.valid && this.submitted;
  }
  addUser() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }

 switch (this.dbops) {
      case Action.create:
        this._userApi.addUser(this.addForm.value).subscribe(res => {
        this._toastr.success("Employee added||", " Employee Registration");
        this.getAllUsers();
       
        this.resetForm();
          this.closeModal();

         
        },
        (error) => {
          console.error('Error occurred during user addition:', error);
          // Handle the error if necessary, e.g., show an error toast.
        }
        
        );
        break;
      case Action.update:
        this._userApi.updateUser(this.addForm.value).subscribe(res => {
        this._toastr.success("Employee updated", "Employee Registration");
        this.getAllUsers();
        
        this.resetForm();
          this.closeModal();
        },
        (error) => {
          console.error('Error occurred during user update:', error);
          // Handle the error if necessary, e.g., show an error toast.
        });
        break;
    }
    
    
   
  
    
    
  
    console.log(this.addForm.value);
    console.log(this.addForm.valid);
    this.addForm.reset();
    this.submitted = true;
    this._toastr.success("added Employee", "employee registration");

  }
  updateUser(user: User) {
    return this._httpService.post('${this.API_BASE_PATH}users/${user.serialno}', user);
  }
  getAllUsers() {
    this._userApi.getUsers().subscribe((res: User[]) => {
      this.userData = res;
      console.log('Fetched Users:', this.userData);
    });
  }


  openXl(content: any) {
    this.modalRef = this.modalService.open(this.elContent, { size: 'xl' });

  }

  edit(userId: number) {

    this.buttontext = "Update";
    this.formTitle = "Update Employee";
    this.dbops = Action.update;
let user = this.userData.find((u: User) => u.id === userId);
const dobDate = new Date(user.DOB);
const dobFormatted = dobDate.toISOString().slice(0, 10);
user.DOB = dobFormatted;

this.addForm.patchValue(user);
if (this.dbops === Action.update) {
  this.addForm.get("serialno")?.disable();
}
    this.modalRef = this.modalService.open(this.elContent, { size: 'xl' });
  }
  
  delete(id: number) {
    console.log('Delete method called with id:', id);
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      cancelButtonText: 'Yes, keep  it!',
      confirmButtonText: 'No, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this._userApi.deleteUser(id).subscribe(res => {
          console.log('Delete API response:', res);
          this.getAllUsers();
          Swal.fire(
            'Deleted!',
            'User data has been deleted.',
            'success'
          );
          
        (error) => {
          console.error('Error occurred during delete:', error);
          // Handle the error if necessary, e.g., show an error toast.
        }
          
        });

     } else {
        Swal.fire(
          'Cancel!',
          'Your record is safe',
          'error'
        )
      }
    });
  };
  closeModal() {
    if (this.modalRef) {
      this.modalRef.dismiss("Cross click");
    }
  }
}
