// action.enum.ts
export enum Action {
    create = 'create',
    update = 'update',
  }
  