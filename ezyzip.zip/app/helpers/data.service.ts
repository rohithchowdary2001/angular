import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { User } from './user.interface';

import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataService implements InMemoryDbService {
 
constructor() { }

  
createDb() {
  let users: User[] = [
    { id: 1, serialno: 1 ,Name: 'anu' , Email: 'anu@gmail.com', Mobileno: '7901236114', DOB: '4-10-1987' },
    { id: 2, serialno: 2, Name: 'giri',  Email: 'gir@gmail.com', Mobileno: '7901234414', DOB: '2-10-1927' },
    { id: 3, serialno: 3, Name: 'sai',  Email: 'saiu@gmail.com', Mobileno: '7902526114', DOB: '2-10-1957' },
    { id: 4, serialno: 4,Name: 'poori',  Email: 'pori@gmail.com', Mobileno: '7901236114', DOB: '4-10-1917' },
  ];

  console.log('Users:', users);

  return {'api/users': users };
}



}
