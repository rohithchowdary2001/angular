import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user.interface';
@Injectable({
  providedIn: 'root'
})
export class UserApi {
  private API_BASE_PATH = "http://localhost:4200/api";


  constructor(private _httpService: HttpClient) { }

  getUsers() {
    return this._httpService.get<User[]>(`${this.API_BASE_PATH}/users`); // Add a slash before "users"
  }

  getUser(userserialno: number) {
    return this._httpService.get<User>(`${this.API_BASE_PATH}/users/${userserialno}`); // Add slashes before and after "users"
  }

  addUser(user: User) {
    return this._httpService.post<User>(`${this.API_BASE_PATH}/users`, user); // Add a slash before "users"
  }

  updateUser(user: User) {
    return this._httpService.put(`${this.API_BASE_PATH}/users/${user.id}`, user); // Add slashes before and after "users"
  }

  deleteUser(userserialno: number) {
    const url = `${this.API_BASE_PATH}/users/${userserialno}`; // Add slashes before and after "users"
    return this._httpService.delete(url);
  }
}