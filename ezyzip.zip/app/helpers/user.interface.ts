export interface User {
  id: number;
  serialno: number;
  Name: string;
  Email: string;
  Mobileno: string;
  DOB: string;
}
