import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortTable'
})
export class SortTablePipe implements PipeTransform {
  transform(data: any[], columnName: string, sortAsc: boolean): any[] {
    if (!data || data.length === 0) {
      return [];
    }

    return data.sort((a, b) => {
      
      if (columnName === 'serialno') {
        return sortAsc ? a.serialno - b.serialno : b.serialno - a.serialno;
      }
      
     
      return 0;
    });
  }
}
